num_classes = 4096

swift_template = """\
final class Example{index} {{
    let value: Int

    init(value: Int) {{
        self.value = value
    }}
}}
"""

for i in range(1, num_classes + 1):
    class_code = swift_template.format(index=i)
    file_name = f"Example{i}.swift"
    with open(file_name, "w") as f:
        f.write(class_code)



output_file = "AllFileExamples.swift"

class_template = """\
final class FileExample{index} {{
    let value: Int

    init(value: Int) {{
        self.value = value
    }}
}}

"""

all_classes = ""
for i in range(1, num_classes + 1):
    all_classes += class_template.format(index=i)

with open(output_file, "w") as f:
    f.write(all_classes)



output_file = "Umbrella.swift"

swift_code = "final class Umbrella {\n"
for i in range(1, num_classes + 1):
    swift_code += f"    let example{i} = Example{i}(value: {i})\n"
for i in range(1, num_classes + 1):
    swift_code += f"    let fileExample{i} = FileExample{i}(value: {i})\n"
swift_code += "\n    func printValues() {\n"
for i in range(1, num_classes + 1):
    swift_code += f"        print(example{i}.value)\n"
for i in range(1, num_classes + 1):
    swift_code += f"        print(fileExample{i}.value)\n"
swift_code += "    }\n"
swift_code += "}\n"

with open(output_file, "w") as f:
    f.write(swift_code)
