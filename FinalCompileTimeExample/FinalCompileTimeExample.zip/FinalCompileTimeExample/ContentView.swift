//
//  ContentView.swift
//  FinalCompileTimeExample
//
//  Created by Volodymyr Andriienko on 27.04.2025.
//

import SwiftUI

struct ContentView: View {
    private let umbrella = Umbrella()

    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
        .onAppear {
            umbrella.printValues()
        }
    }
}

#Preview {
    ContentView()
}
