//
//  FinalCompileTimeExampleApp.swift
//  FinalCompileTimeExample
//
//  Created by Volodymyr Andriienko on 27.04.2025.
//

import SwiftUI

@main
struct FinalCompileTimeExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
